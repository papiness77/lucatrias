//import org.junit.Test;
//
//import static org.junit.Assert.assertEquals;
//
//public class test {
//  @Test
//    public void test(){
//      ProductoPerecedero productoPerecedero= new ProductoPerecedero("Leche","Arg",34,90,30);
//      productoPerecedero.setCosto(10);
//      float valorEsperarado=30;
//      float valorObtenido= productoPerecedero.calcularPrecioFinal();
//      assertEquals(valorEsperarado,valorObtenido,0);
//  }
//}
//