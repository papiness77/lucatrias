public class main{
    public static void main(String[]args){
        SistemaSuperMercado hola = new SistemaSuperMercado("DIA");

        SistemaSuperMercado.serealizar();
    }
}
