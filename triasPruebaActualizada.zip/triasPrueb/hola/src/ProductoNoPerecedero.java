public class ProductoNoPerecedero extends ProductoAlimenticio{
    private int mgDeSodio;
    public ProductoNoPerecedero(String nombre, String origen, int codigo,  int cantDiasParaVencerse,int mgDeSodio) {
        super(nombre, origen, codigo,cantDiasParaVencerse);
        this.mgDeSodio=mgDeSodio;
    }

    public int getMgDeSodio() {
        return mgDeSodio;
    }

    public void setMgDeSodio(int mgDeSodio) {
        this.mgDeSodio = mgDeSodio;
    }
}
