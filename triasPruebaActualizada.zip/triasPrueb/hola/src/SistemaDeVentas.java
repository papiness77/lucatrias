public interface SistemaDeVentas {
    public float gananciaTotalObtenida();
    public float ingresosTotales();
    public int cantidadDeProductosVendidos();
}
