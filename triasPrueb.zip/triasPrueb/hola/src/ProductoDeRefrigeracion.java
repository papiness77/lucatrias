public class ProductoDeRefrigeracion extends ProductoElectrico{
    private int litrosDeCapacidad;
    public ProductoDeRefrigeracion(String nombre, String origen, int codigo, int cantDiasGarantia,int litrosDeCapacidad) {
        super(nombre, origen, codigo, cantDiasGarantia);
        this.litrosDeCapacidad=litrosDeCapacidad;
    }

    public int getLitrosDeCapacidad() {
        return litrosDeCapacidad;
    }

    public void setLitrosDeCapacidad(int litrosDeCapacidad) {
        this.litrosDeCapacidad = litrosDeCapacidad;
    }
}
