public abstract class ProductoElectrico extends ProductoDeSuper{
    private int cantDiasGarantia;
    private static int RECARGO_POR_ENVIO;
    public ProductoElectrico(String nombre, String origen, int codigo,int cantDiasGarantia) {
        super(nombre, origen, codigo);
        this.cantDiasGarantia=cantDiasGarantia;
    }

    @Override
    public float calcularPrecioFinal() {
        float precioFinal=this.getCosto()+this.calcularGananciaObtenida()+RECARGO_POR_ENVIO;
        return precioFinal;
    }

    @Override
    public float calcularGananciaObtenida() {
        int porcentajeDeGanacia= Integer.parseInt(null);
        if(this.cantDiasGarantia == 365){
            porcentajeDeGanacia=45;
        }
        else if(this.cantDiasGarantia<=60){
            porcentajeDeGanacia=15;
        }
        return porcentajeDeGanacia;
    }

    @Override
    public String tipoDeProducto() {
        return "Producto Electrico";
    }


}


