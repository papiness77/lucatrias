import com.fasterxml.jackson.core.*;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Scanner;

public class SistemaSuperMercado implements SistemaDeVentas {
    private String nombre;
    private HashSet<ProductoDeSuper> productosDisponiblesALaVenta;
    private ArrayList<ProductoDeSuper> productosYaVendidos;

    public SistemaSuperMercado(String nombre) {
        this.nombre = nombre;
        this.productosDisponiblesALaVenta = new HashSet<>();
        this.productosYaVendidos = new ArrayList<>();
    }


    public void agregarProductoVendido() {
        Scanner scanner = new Scanner(System.in);
        boolean terminado=true;
        while (terminado) {
            try {
                System.out.println("Ingrese nombre");
                String nombre = scanner.nextLine();
                System.out.println("Ingrese Origen");
                String origen = scanner.nextLine();
                System.out.println("Ingrese codigo");
                int codigo= scanner.nextInt();
                System.out.println("Ingrese 1-Producto Perecedero,2-Producto No Perecedero,3-Poducto Calefaccion,4-Producto Refrigeracion");
                int eleccion = scanner.nextInt();
                int cantDias;
                switch (eleccion){
                    case 1:
                        System.out.println("Ingrese cantDiasParaVencerse");
                        cantDias= scanner.nextInt();
                        System.out.println("Ingrese temp frio");
                        int temp =scanner.nextInt();
                        ProductoPerecedero productoPerecedero = new ProductoPerecedero(nombre,origen,codigo,cantDias,temp);
                        this.productosYaVendidos.add(productoPerecedero);
                        terminado=false;
                        break;
                    case 2:
                        System.out.println("Ingrese cantDiasParaVencerse");
                        cantDias = scanner.nextInt();
                        System.out.println("Ingrese mgDeSodio");
                        int mgDeSodio =scanner.nextInt();
                        ProductoNoPerecedero productoN = new ProductoNoPerecedero(nombre,origen,codigo,cantDias,mgDeSodio);
                        this.productosYaVendidos.add(productoN);
                        terminado=false;
                        break;
                    case 3:
                        System.out.println("Ingrese garantia");
                        cantDias = scanner.nextInt();
                        System.out.println("Ingrese watts");
                        int watts =scanner.nextInt();
                        ProductoDeCalefaccion productoDeCalefaccion = new ProductoDeCalefaccion(nombre,origen,codigo,cantDias,watts);
                        this.productosYaVendidos.add(productoDeCalefaccion);
                        terminado=false;
                        break;
                    case 4:
                        System.out.println("Ingrese garantia");
                        cantDias = scanner.nextInt();
                        System.out.println("Ingrese litros");
                        int litros =scanner.nextInt();
                        ProductoDeRefrigeracion productoDeRefrigeracion = new ProductoDeRefrigeracion(nombre,origen,codigo,cantDias,litros);
                        this.productosYaVendidos.add(productoDeRefrigeracion);}
                        terminado=false;
                        break;
                }
            catch (Exception InputMismatchException){
                System.out.println("Ingresaste mal");
            }
        }
    }

    public static void serealizar(){
        ObjectMapper mapper1 = new ObjectMapper();
        ProductoPerecedero a = new ProductoPerecedero("hola","arg",2,3,5);

        HashMap<String,Object> mapASerializar = new HashMap<>();
        ArrayList<ProductoDeSuper> productoDeSupers = new ArrayList<>();
        productoDeSupers.add(a);

        mapASerializar.put("prodcuto",productoDeSupers);

        String objetoJson1 = null;
        try {
            objetoJson1 = mapper1.writeValueAsString(mapASerializar);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        System.out.println(objetoJson1);
    }
    public static void desSerealizar(){
        ObjectMapper mapper2 = new ObjectMapper();
        String json1 = "{ \"nombre\":\"hola\"," +
                "\"origen\" : \"hola\",\"," + "\"codigo\":\"2\"," +
                "\"cantDiasParaVencerse\":\"4\"," +
                "\"temperaturaMinimaDeFrio\":\"50\"," +
                "}";

        HashMap map1 = null;
        try {
            map1 = mapper2.readValue(json1, HashMap.class);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        System.out.println(map1);
    }



    @Override
    public float gananciaTotalObtenida() {
        float ganaciaFinal = 0;
        for(ProductoDeSuper productoDeSuper:this.productosYaVendidos){
            ganaciaFinal+=productoDeSuper.getCosto();
        }
        return ganaciaFinal;
    }


    @Override
    public float ingresosTotales() {
        float ingresos = 0;
        for(ProductoDeSuper productoDeSuper:this.productosYaVendidos){
            ingresos+=productoDeSuper.calcularGananciaObtenida();
        }
        return ingresos;
    }

    @Override
    public int cantidadDeProductosVendidos() {
        return this.productosYaVendidos.size();
    }
}
