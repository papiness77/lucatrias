public interface Producto {
    public float calcularPrecioFinal();
    public float calcularGananciaObtenida();
    public String tipoDeProducto();
}
