public abstract class ProductoAlimenticio extends ProductoDeSuper{
    private int cantDiasParaVencerse;
    private static int DESCUENTO=10;
    public ProductoAlimenticio(String nombre, String origen, int codigo,int cantDiasParaVencerse) {
        super(nombre, origen, codigo);
        this.cantDiasParaVencerse=cantDiasParaVencerse;
    }

    @Override
    public float calcularPrecioFinal() {
        float precioFinal=this.getCosto()+this.calcularGananciaObtenida()+DESCUENTO;
        return precioFinal;
    }

    @Override
    public float calcularGananciaObtenida() {
        int porcentajeDeGanacia = 0;
        if(this.cantDiasParaVencerse<=90){
            porcentajeDeGanacia=10;
        }
        else if (this.cantDiasParaVencerse>90){
            porcentajeDeGanacia=25;
        }

        return porcentajeDeGanacia;

    }

    @Override
    public String tipoDeProducto() {
        return "Producto Alimenticio";
    }
}






