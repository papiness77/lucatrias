public class ProductoPerecedero extends ProductoAlimenticio{
    private int temperaturaMinimaDeFrio;
    public ProductoPerecedero(String nombre, String origen, int codigo, int cantDiasParaVencerse,int temperaturaMinimaDeFrio) {
        super(nombre, origen, codigo, cantDiasParaVencerse);
        this.temperaturaMinimaDeFrio=temperaturaMinimaDeFrio;
    }
}
