public class ProductoDeCalefaccion extends ProductoElectrico{
    private int wattsDePotenciaMaxima;
    public ProductoDeCalefaccion(String nombre, String origen, int codigo, int cantDiasGarantia,int wattsDePotenciaMaxima) {
        super(nombre, origen, codigo, cantDiasGarantia);
        this.wattsDePotenciaMaxima=wattsDePotenciaMaxima;
    }


}
