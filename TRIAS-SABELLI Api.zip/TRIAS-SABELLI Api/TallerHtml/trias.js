var queBotonEstoy=0;
var idInput=  document.getElementById("idinput");
var nombreInput =document.getElementById("nombreinput");
var edadInput =document.getElementById("edadinput");
var botonDeIngreso=document.getElementById("botonDeIngreso");
var infoACambiar=document.getElementById("infoACambiar")

function obtenerDatosTodos(){
    noDisplayInputs()

$.ajax({
        url: "url: http://localhost:8080/api/datos/alumnos",
        type: 'GET',
})
.done(function (data) {

    infoACambiar.innerHTML=data;

})
.fail(function (jqXHR, textStatus, errorThrown) {
    console.log("error, no se pudo ingresar los nuevos datos");
    console.log(jqXHR);
    console.log(textStatus);
    console.log(errorThrown);
});
}

function obtenerDatosDeUnID(){
    noDisplayInputs()
    idInput.style.display="inline-block";
    botonDeIngreso.style.display="inline-block";
    queBotonEstoy=1;
   
}
function realizarRegistro(){
    idInput.style.display="inline-block";
    nombreInput.style.display="inline-block";
    edadInput.style.display="inline-block";
    botonDeIngreso.style.display="inline-block";
    queBotonEstoy=2;
    
}
function realizarModificacion(){
    nombreInput.style.display="inline-block";
    edadInput.style.display="inline-block";
    idInput.style.display="inline-block";
    botonDeIngreso.style.display="inline-block";
    queBotonEstoy=3;
    
}
function eliminarAlumno(){
    noDisplayInputs()
    idInput.style.display="inline-block";
    botonDeIngreso.style.display="inline-block";
    queBotonEstoy=4;
}
function llamadoALaApi(){
    var infoId=idInput.value;
    var infoNombre=nombreInput.value;
    var infoEdad=edadInput.value;
    switch (queBotonEstoy){
        case 1:
            $.ajax({
                url: "url: http://localhost:8080/api/datos/alumnos/"+infoId,
                type: 'GET',
        })
        .done(function (data) {
        
            infoACambiar.innerHTML=data;
        
        })
        .fail(function (jqXHR, textStatus, errorThrown) {
            console.log("error, no se pudo ingresar los nuevos datos");
            console.log(jqXHR);
            console.log(textStatus);
            console.log(errorThrown);
        });
        
            break;
        case 2:
        
            let objetoConInformacion = { nombre : infoNombre , edad : infoEdad ,id:infoId };

$.ajax({
        url: "http://localhost:8080/api/datos/alumnos",
        type: 'POST',
        contentType: "application/json",
        data: JSON.stringify(objetoConInformacion)
})
.done(function (data) {

})
.fail(function (jqXHR, textStatus, errorThrown) {
    console.log("error, no se pudo ingresar los nuevos datos");
    console.log(jqXHR);
    console.log(textStatus);
    console.log(errorThrown);
});

            break;
        case 3:
            let objetoConInformacionAActualizar = null;
            if(infoNombre==null){
                objetoConInformacionAActualizar = { edad : infoEdad };
            }
            else{
                objetoConInformacionAActualizar = { nombre : infoNombre };
            }
        

$.ajax({
        url: "url: http://localhost:8080/api/datos/alumnos/"+infoId,
        type: 'PATCH',
        contentType: "application/json",
        data: JSON.stringify(objetoConInformacionAActualizar)
})
.done(function (data) {

  /* hace algo con el objeto "data" recibido, si es que recibe algo*/

})
.fail(function (jqXHR, textStatus, errorThrown) {
    console.log("error, no se pudo ingresar los nuevos datos");
    console.log(jqXHR);
    console.log(textStatus);
    console.log(errorThrown);
});
            break;
        case 4:
            $.ajax({
                url: "url: http://localhost:8080/api/datos/alumnos/"+infoId,
                type: 'DELETE'
        })
        .done(function (data) {
        
        })
        .fail(function (jqXHR, textStatus, errorThrown) {
            console.log("error, no se pudo obtener datos");
            console.log(jqXHR);
            console.log(textStatus);
            console.log(errorThrown);
        });
            break;
    }
    
}


















function noDisplayInputs(){
    idInput.style.display="none";
    nombreInput.style.display="none";
    edadInput.style.display="none";
    botonDeIngreso.style.display="none";
}

