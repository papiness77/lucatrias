package com.example.demo;

public class Persona {

}
