package com.example.demo;
public class Alumno {
    private String nombre;
    private int edad;
    private int id;
    /** completar **/
    public Alumno(String nombre, int edad,int id) {
        this.edad=edad;
        this.nombre=nombre;
        this.id=id;
    }
    public String getNombre() {
        return nombre;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public int getEdad() {
        return edad;
    }
    public void setEdad(int edad) {
        this.edad = edad;
    }
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
}
