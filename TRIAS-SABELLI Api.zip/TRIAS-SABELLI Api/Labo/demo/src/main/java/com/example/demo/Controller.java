package com.example.demo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.*;
/** url: http://localhost:8080/api/... **/
@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class Controller {
    @Autowired
    private AccesoBaseDeDatos accesoABaseDeDatos;
    public Controller() {
        this.accesoABaseDeDatos = new AccesoBaseDeDatos("personas","alumnos");
        this.accesoABaseDeDatos.conectar("alumno","alumnoipm");
    }
    @RequestMapping(value = "/datos/alumnos", method = RequestMethod.GET)
    public ResponseEntity<Object> obtenerPaginas() {
        HashMap<String, Object> datos = accesoABaseDeDatos.obtenerDatos();
        return new ResponseEntity<>(datos, HttpStatus.OK);
    }
    @RequestMapping(value = "/datos/alumnos", method = RequestMethod.POST)
    public ResponseEntity<Object> agregarPagina(@RequestBody HashMap alumno) {
        String nombre = (String) alumno.get("nombre");
        int edad = (int) alumno.get("edad");
        int id = (int) alumno.get("id");
        Alumno nuevoAlumno = new Alumno(nombre, edad,id);
        accesoABaseDeDatos.agregarAlumno(nuevoAlumno);
        return new ResponseEntity<>(HttpStatus.OK);
    }
    @RequestMapping(value = "/datos/alumnos/{id}", method = RequestMethod.GET)
    public ResponseEntity<Object> obtenerPaginaSoloUNo(@RequestBody HashMap alumno) {
        int id=(int) alumno.get("id");
        String id2 = Integer.toString(id);
        HashMap<String, Object> datos = accesoABaseDeDatos.obtenerDatosDeUnAlumno(id2);
        return new ResponseEntity<>(datos, HttpStatus.OK);
    }
    @RequestMapping(value = "/datos/alumnos/{id}", method = RequestMethod.DELETE)
    public ResponseEntity<Object> eliminarPagina(@RequestBody HashMap alumno) {
        int id=(int) alumno.get("id");
        String id2 = Integer.toString(id);
        accesoABaseDeDatos.elimiarAlumno(id2);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @RequestMapping(value = "/datos/alumnos/{id}", method = RequestMethod.PATCH)
    public ResponseEntity<Object> modificarPagina(@RequestBody HashMap alumno) {
        int id=(int) alumno.get("id");
        String id2 = Integer.toString(id);

        String nombre = (String) alumno.get("nombre");
        int edad = (int) alumno.get("edad");
        if(nombre==null){
            accesoABaseDeDatos.updetearAlumnoEdad(id2,edad);
        }
        else{
            accesoABaseDeDatos.updetearAlumnoNombre(id2,nombre);
        }

        return new ResponseEntity<>(HttpStatus.OK);
    }

}
