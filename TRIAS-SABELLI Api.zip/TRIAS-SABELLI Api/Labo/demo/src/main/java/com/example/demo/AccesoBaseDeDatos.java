package com.example.demo;
import org.springframework.stereotype.Service;
import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
@Service
public class AccesoBaseDeDatos {
    private Connection conexion;
    private String nombreBaseDeDatos;
    private String nombreTabla;

    public AccesoBaseDeDatos(String nombreBaseDeDatos, String nombreTabla) {
        this.nombreBaseDeDatos = nombreBaseDeDatos;
        this.nombreTabla = nombreTabla;
    }
    public void conectar(String user, String password) {
         String url = "jdbc:mysql://localhost:3306/" + this.nombreBaseDeDatos;
        //String url = "jdbc:mysql://localhost/" + this.nombreBaseDeDatos + "?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC";

        try {
            conexion = DriverManager.getConnection(url, user, password);
            if (conexion != null) {
                System.out.println("Se ha conectado exitosamente con la base de datos");
            } else {
                System.out.println("No se ha podido conectar con la base de datos");
            }
        } catch (SQLException excepcion) {
            excepcion.printStackTrace();
        }
    }

    public void modificarTabla(String consulta) {
        /* INSERT, UPDATE, DELETE */
        try {
            Statement sentencia = this.conexion.createStatement();
            sentencia.executeUpdate(consulta);
            sentencia.close();
        } catch (SQLException excepcion) {
            excepcion.printStackTrace();
        }
    }
    public ResultSet obtenerResultado(String consulta){
        ResultSet resultado = null;
        try {
            Statement sentencia = this.conexion.createStatement();
            resultado = sentencia.executeQuery(consulta);

        } catch (SQLException excepcion) {
            excepcion.printStackTrace();
        }
        return resultado;
    }
    public ResultSet seleccionarTodo(){
        String consulta = "SELECT * FROM " + this.nombreTabla;
        ResultSet resultado = this.obtenerResultado(consulta);
        return resultado;
    }
    public ResultSet seleccionarAUnALumno(String id){
        String consulta = "SELECT * FROM " + this.nombreTabla+"WHERE idAlumnos="+id+";";
        ResultSet resultado = this.obtenerResultado(consulta);
        return resultado;
    }
    public void imprimirDatos() {
        ResultSet resultado = this.seleccionarTodo();
        try {
            while (resultado.next()) {
                int id = resultado.getInt("id");
                String nombre = resultado.getString("nombre");
                int edad = resultado.getInt("edad");
                System.out.println(id + " " + nombre +" "+ edad);
            }
            resultado.close();
        } catch (SQLException excepcion) {
            excepcion.printStackTrace();
        }
    }
    public ResultSet mostrarColumnas(){
        String consulta = "SHOW COLUMNS FROM " + this.nombreTabla;
        ResultSet resultado = this.obtenerResultado(consulta);
        return resultado;
    }
    public ArrayList<String> colocarCamposEnLista() {
        ArrayList<String> nombresDeCampos = new ArrayList<>();
        ResultSet resultado = this.mostrarColumnas();
        try {
            while (resultado.next()) {
                String nombreDeColumna = resultado.getString("field");
                nombresDeCampos.add(nombreDeColumna);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return nombresDeCampos;
    }
    public HashMap<String,Object> obtenerDatos(){
        HashMap<String,Object> datos = new HashMap<>();
        ResultSet resultado = this.seleccionarTodo();
        ArrayList<Alumno> alumnoArrayList=new ArrayList<>();
        try {
            while (resultado.next()) {
                int id = resultado.getInt("id");
                String nombre = resultado.getString("nombre");
                int edad = resultado.getInt("edad");
                Alumno alumno = new Alumno(nombre,edad,id);
                alumnoArrayList.add(alumno);
            }
            resultado.close();
        } catch (SQLException excepcion) {
            excepcion.printStackTrace();
        }
        datos.put("Alumnos: ",alumnoArrayList);

        return datos;
    }
    public void agregarAlumno(Alumno alumno) {
        String nombre = alumno.getNombre();
        int edad = alumno.getEdad();
        int id = alumno.getId();
        String consulta = "INSERT INTO `personas`.`alumnos`" +
                "(`idAlumnos`," +
                "`nombreAlumno`," +
                "`edadAlumno`)" +
                "VALUES" +
                "("+id+ ", `" +
                nombre+"`," +
                edad+");";
        this.modificarTabla(consulta);
    }
    public void elimiarAlumno(String id) {
        String consulta = "DELETE FROM `personas`.`alumnos` WHERE 'idAlumnos'=" +id+
                ";";
        this.modificarTabla(consulta);
    }
    public void updetearAlumnoNombre(String id,String nombre) {
        String consulta = "UPDATE `personas`.`alumnos` SET ´nombreAlumno' ='" +nombre+"'"+"WHERE 'idAlumnos'="+id+";";
        this.modificarTabla(consulta);
    }
    public void updetearAlumnoEdad(String id,int edad) {
        String consulta = "UPDATE `personas`.`alumnos` SET ´edadAlumno' =" +edad+"WHERE 'idAlumnos'="+id+";";
        this.modificarTabla(consulta);
    }
    public HashMap<String,Object> obtenerDatosDeUnAlumno(String idA){
        HashMap<String,Object> datos = new HashMap<>();
        ResultSet resultado = this.seleccionarAUnALumno(idA);
        Alumno alumno = new Alumno("",0,0);
        try {
            while (resultado.next()) {
                int id = resultado.getInt("id");
                String nombre = resultado.getString("nombre");
                int edad = resultado.getInt("edad");
                alumno.setId(id);
                alumno.setEdad(edad);
                alumno.setNombre(nombre);
            }
            resultado.close();
        } catch (SQLException excepcion) {
            excepcion.printStackTrace();
        }
        datos.put("Alumno: ",alumno);
        return datos;
    }
    /*
    Colocar mysql-connector-java-8.0.21.jar en una carpeta llamada lib
    File -> Project Structure -> + -> JARs y directorios ->
    seleccionar mysql-connector-java-8.0.21.jar -> tildar -> aplicar -> ok
    */
}